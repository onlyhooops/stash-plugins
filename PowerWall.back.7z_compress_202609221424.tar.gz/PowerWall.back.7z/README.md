# PowerWall

Stash 原生风格的**砌墙视图**插件：在图片/短片列表页提供列优先递补布局、等比例缩放的墙视图，支持无限滚动与内置 Lightbox。

## 功能

- **砌墙布局**：列优先递补（最短列放置），缩略图等比例缩放、无剪裁无拉伸
- **6 档缩放**：滑块调节列宽（160～640px），仅滑块无文字
- **布局预设**：无缝 / 紧凑 / 标准 / 宽松（边距、行距、列距；无缝为无间距拼接）
- **无限滚动**：触底自动加载下一页
- **内置 Lightbox**：点击图片全屏浏览，支持缩放、拖拽、1:1、左右切换与向下拖拽关闭；左上角显示图片名、计数器及图库名（可点击跳转）；右下角竖向缩放按钮；进入/退出时无布局偏移
- **返回顶部**：右下角浮动 TOP 按钮，滚动一定距离后显示，点击平滑回到顶部
- **工具栏自适应**：单行不换行；已加载/总数简写（如 1.7M）；宽度足够时按钮显示图标+文字，变窄时仅图标；关键词通过筛选面板使用（工具栏无搜索框以减轻性能影响）
- **随阅**：随机打开一个图库内的全部图片/视频，在当前砌墙中展示（仅图片页，与随览不同：随览完全随机，随阅随机选图库）
- **视频悬停**：短片卡片悬停时预播预览片段
- **筛选**：关键词、路径、排序、标签/演员/工作室
- **协作**：`enhancedWallItemAdded` 事件，兼容 FavoriteHeart 等插件
- **作用范围**：仅 `/images`、`/scenes` 列表；小屏/触屏不启用

## 安装

将 `PowerWall` 目录放入 Stash 的 `plugins` 目录，在 **设置 → Plugins** 中重载插件。

## 兼容性

- **Stash**：需支持 UI 插件的版本（通常 v0.25+）
- **作用页面**：`/images` 与 `/scenes` 列表页
- **不作用**：`/tags`、`/galleries`、`/performers`、`/studios`、`/movies`、`/markers` 及详情页等

## 功能边界

1. 仅替换 `/images`、`/scenes` 根列表页的墙/网格内容，不影响其它页面
2. 使用 `PluginApi.Event` 监听 `stash:location` 实现路由感知；无 PluginApi 时使用 history API 备选
3. 使用 Stash 标准 `/graphql` 端点，不调用非公开接口
4. 样式与 DOM 均限定在 `.power-wall-*` 命名空间内
5. 离开列表页时完整卸载并清理 DOM、事件、全局状态

## URL 筛选参数

| 参数 | 说明 |
|------|------|
| `q` | 关键词搜索 |
| `path` | 路径包含过滤（支持筛选面板选择） |
| `tags` | 标签 ID，逗号分隔 |
| `performers` | 演员 ID，逗号分隔 |
| `studios` | 工作室 ID，逗号分隔 |
| `galleries` | 图库 ID（仅图片页） |
| `sortby` | 排序字段（created_at / date / title / rating100 / updated_at / random_&lt;seed&gt;） |
| `sortdir` | 排序方向，`ASC` 或 `DESC` |

## 配置

在列表页工具栏点击「⚙️ 设置」配置，保存至 `localStorage`（键：`PowerWall_config`）。

### 布局预设

无缝 / 紧凑 / 标准 / 宽松，分别调节边距、行距、列距。无缝模式下图片之间无行距、列距与边距，实现无缝拼接。

### 功能开关

| 项 | 说明 |
|----|------|
| 图片列表启用 | 是否在 `/images` 启用砌墙 |
| 短片列表启用 | 是否在 `/scenes` 启用砌墙 |
| 内置 lightbox | 点击图片在内置 lightbox 浏览 |
| 高级 | 每页数量（12～120）、调试模式 |

### 筛选

点击「🔍 筛选」打开筛选面板，支持关键词、路径、排序、标签/演员/工作室多选，与 URL 同步。

## 性能与鲁棒性

- **无限滚动**：IntersectionObserver，无 scroll 轮询
- **布局**：ResizeObserver + debounce；DOM 批量插入、单次高度更新
- **请求**：GraphQL 支持 AbortSignal（刷新/离开时取消）、30s 超时
- **配置**：缓存、localStorage 读写异常处理、zoomIndex/itemsPerPage 范围校验
- **Lightbox**：复用 overlay 时正确更新 prev/next 索引，键盘与鼠标事件按需绑定/解绑
- **路由**：PluginApi.Event 或 history fallback，离开时完整卸载

## 技术实现

- **规范**：遵循 [Stash UI Plugin API](https://docs.stashapp.cc/in-app-manual/plugins/uipluginapi/)
- **数据**：GraphQL `findImages` / `findScenes` / `findFolders` 等
- **路由**：`PluginApi.Event` 监听 `stash:location`，无 `PluginApi.patch` 避免 React 冲突

## 版本

### 1.6.0

- **Lightbox 信息栏**：左上角两行排版 — 第一行：图片名 + 计数器（如 `A38A4545.png 3/40`）；第二行：图库名称（主题色高亮、可点击跳转至 `/galleries/{id}`）
- **图库名称获取**：优先从 `findImages` 的 `galleries` 读取；URL 含 `galleries=` 时从 `findGallery` 获取；缺失时按需请求 `findGallery` 并缓存
- **Lightbox 左右切换按钮**：由圆形改为圆角矩形（`border-radius: 10px`），与工具栏按钮风格一致

### 1.5.0

- **Lightbox 现代化**：工具栏（−/+、1:1）移至右下角竖向排列；双击 1:1 切换；Loading Spinner 替代淡入淡出；移除滚动条；向下拖拽关闭；随阅模式下刷新回首页

### 1.4.3

- **无缝模式**：新增布局预设「无缝」，图片之间无行距、列距与边距，实现无缝拼接（在紧凑之上）

### 1.4.2

- **随阅**：新增「📖 随阅」按钮，随机打开一个图库内的全部资源并在当前砌墙中展示（不跳转页面）
- 与「随览」区别：随览为完全随机排序；随阅为随机选取一个图库后再展示其内全部图片/视频
- 仅图片页显示该按钮，短片页隐藏（图库筛选仅作用于图片）

### 1.4.1

- **移除工具栏关键词搜索框**：避免影响 Stash 性能；关键词仍可通过「🔍 筛选」面板使用，URL 参数 `q` 与查询逻辑不变

### 1.4.0

- **工具栏自适应**：尽量不换行（flex-nowrap），窄屏压缩间距与搜索框
- **已加载/总数简写**：大数显示为 1K、1.5K、1.7M 等，减少占位
- **功能按钮响应式**：宽度 >720px 显示图标+文字，≤720px 仅显示图标，节省空间

### 1.3.0

- **视图偏移修复**：进入/退出 lightbox 或 rightbox 时，消除砌墙整体左移
  - 支持 `scrollbar-gutter` 时不再叠加 `paddingRight`，避免双重补偿
  - 视口/滚动条变化检测：ResizeObserver + 定时检查，保持布局与真实可用宽度一致
  - scrollbar-gutter 作用于 html，符合规范
- **返回顶部**：右下角浮动 TOP 按钮（矩形、Stash 原生风格、毛玻璃效果），滚动 200px 后显示，点击平滑回到顶部

### 1.2.0（定稿版）

- Lightbox 复用修复：再次打开时 prev/next 与索引正确更新
- 移除 BrickWallLayout 冗余 zoomIndex，布局列宽统一从 getConfig 读取
- 4K/1080p 分辨率角标样式（resolution-4k、resolution-hd）
- 代码简化与鲁棒性增强

### 1.1.0

- 配置读写防错、布局计算优化、Lightbox/筛选/无限滚动边界检查
- 配置项校验（zoomIndex、itemsPerPage 范围）与 localStorage 写入异常处理

### 1.0.0

- 初始版本：砌墙布局（列优先递补）、6 档缩放、布局预设、无限滚动、内置 Lightbox、筛选与设置
